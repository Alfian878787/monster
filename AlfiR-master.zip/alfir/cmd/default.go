package cmd

import (
	"gitea.com/Alfian878787/AlfiR/config"

	"gitea.com/jolheiser/beaver"
	"gitea.com/jolheiser/beaver/color"

	"github.com/urfave/cli/v2"
)

func DefaultAction(ctx *cli.Context) error {
	cfg, err := config.New(ConfigFlag)
	if err != nil {
		return err
	}

	beaver.Info("Thanks for using cli! Here is your example config:\n")
	color.Info = color.New(color.FgBlue)
	beaver.Infof("%#v\n", cfg)

	return nil
}
