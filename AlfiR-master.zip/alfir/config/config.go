package config

import (
	"io/ioutil"

	"gitea.com/jolheiser/beaver"

	"github.com/BurntSushi/toml"
)

var defaultConfig = []byte(`# The logging level for AlfiR
log_level = "Info"
`)

// Config represents a AlfiR configuration
type Config struct {
	LogLevel string `toml:"log_level"`
}

// New loads a new AlfiR configuration
func New(configPath string) (*Config, error) {
	var cfg *Config
	var err error
	var configContent []byte

	if len(configPath) == 0 {
		configContent = defaultConfig
	} else {
		configContent, err = ioutil.ReadFile(configPath)
		if err != nil {
			return nil, err
		}
	}

	if _, err := toml.Decode(string(configContent), &cfg); err != nil {
		return nil, err
	}

	beaver.Console.Level = beaver.ParseLevel(cfg.LogLevel)
	return cfg, nil
}
