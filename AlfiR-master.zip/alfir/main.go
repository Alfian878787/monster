package main

import (
	"os"
	"strings"

	"gitea.com/Alfian878787/AlfiR/cmd"

	"gitea.com/jolheiser/beaver"

	"github.com/urfave/cli/v2"
)

var (
	Version     = "development"
	description = "Male all extention more fast and get a good performance as/ android 10"
)

func main() {
	app := &cli.App{
		Name:        "AlfiR",
		Version:     Version,
		Usage:       strings.Split(description, ".")[0],
		Description: description,
		Action:      cmd.DefaultAction,
		Flags: []cli.Flag{
			&cli.StringFlag{
				Name:        "config",
				Aliases:     []string{"c"},
				Usage:       "Path to the AlfiR config file (e.g. .AlfiR.toml)",
				Destination: &cmd.ConfigFlag,
			},
		},
	}

	if err := app.Run(os.Args); err != nil {
		beaver.Fatal(err)
	}
}
