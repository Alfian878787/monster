# Changelog
[Check out the release notes](https://gitea.com/gitnex/GitNex/releases)
