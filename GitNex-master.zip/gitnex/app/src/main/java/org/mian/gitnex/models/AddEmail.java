package org.mian.gitnex.models;

import java.util.List;

/**
 * Author M M Arif
 */

public class AddEmail {

    private List<String> emails;

    public AddEmail(List<String> emails) {
        this.emails = emails;
    }

}
