package org.mian.gitnex.models;

/**
 * Author M M Arif
 */

public class GiteaVersion {

    private String version;

    public String getVersion() {
        return version;
    }

}
