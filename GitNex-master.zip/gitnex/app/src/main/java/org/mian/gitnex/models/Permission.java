package org.mian.gitnex.models;

/**
 * Author M M Arif
 */

public class Permission {

    private String permission;

    public Permission(String permission) {
        this.permission = permission;
    }
}
