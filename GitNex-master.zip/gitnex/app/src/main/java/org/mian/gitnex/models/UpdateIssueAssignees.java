package org.mian.gitnex.models;

import java.util.List;

/**
 * Author M M Arif
 */

public class UpdateIssueAssignees {

    private List<String> assignees;

    public UpdateIssueAssignees(List<String> assignees) {
        this.assignees = assignees;
    }

}
