package org.mian.gitnex.models;

/**
 * Author M M Arif
 */

public class UpdateIssueState {

    private String state;

    public UpdateIssueState(String state) {
        this.state = state;
    }
}
