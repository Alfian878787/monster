# SimpleExpertSystemAI
Aplikasi sistem pakar sederhana untuk mendeteksi apakah pengguna terkene infeksi pada sistem gastro-usus ataukah tidak

Link .apk untuk percobaan (minimal android 4.2) : https://drive.google.com/open?id=0B5u2kPTgUL8uc0ZvWFBlMzZKT1k
